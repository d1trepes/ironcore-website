/* IRONCORE — vanilla, no dependencies. Same file runs the static demo and the WordPress theme. */
(function () {
  'use strict';
  /* window.IRONCORE is printed by the WordPress theme (ajaxUrl, nonce, phone, file limits).
     Without it (static demo / GitHub Pages) the form stays in honest demo mode. */
  var CFG = window.IRONCORE || null;
  var PHONE = (CFG && CFG.phone) || '8 (928) 416-09-38';
  var PHONE_HREF = (CFG && CFG.phoneHref) || 'tel:+79284160938';
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  $$('[data-year]').forEach(function (el) { el.textContent = new Date().getFullYear(); });

  /* ---- Header: solid after hero top, hides on scroll down, returns on scroll up ---- */
  var header = $('#header'), burger = $('.burger'), drawer = $('#drawer');
  var mobile = window.matchMedia('(max-width: 960px)');
  var lastY = window.scrollY, locked = false;
  function onScroll() {
    if (locked) return;
    var y = window.scrollY;
    header.classList.toggle('is-solid', y > 24);
    var edge = mobile.matches ? 240 : 480;
    if (y > edge && y > lastY + 4) header.classList.add('is-hidden');
    else if (y < lastY - 4 || y <= edge) header.classList.remove('is-hidden');
    lastY = y;
  }

  /* ---- Page scroll lock (works on iOS too): used by the drawer ---- */
  var lockY = 0;
  function lockScroll() {
    if (locked) return;
    lockY = window.scrollY; locked = true;
    var b = document.body.style;
    b.position = 'fixed'; b.top = -lockY + 'px'; b.left = '0'; b.right = '0'; b.width = '100%';
  }
  function unlockScroll() {
    if (!locked) return;
    var b = document.body.style;
    b.position = b.top = b.left = b.right = b.width = '';
    document.documentElement.style.scrollBehavior = 'auto';
    window.scrollTo(0, lockY);
    document.documentElement.style.scrollBehavior = '';
    lastY = lockY; locked = false;
  }

  /* ---- Mobile drawer menu: slides in from the right ---- */
  var drawerPanel = $('.drawer__panel', drawer), drawerTimer = null;
  function focusables() { return $$('a[href], button:not([disabled])', drawerPanel); }
  function openMenu() {
    clearTimeout(drawerTimer);
    drawer.hidden = false;
    lockScroll();
    drawer.offsetWidth; // start the slide from the closed state
    drawer.classList.add('is-open');
    burger.setAttribute('aria-expanded', 'true');
    burger.setAttribute('aria-label', 'Закрыть меню');
    $('.drawer__close', drawer).focus({ preventScroll: true });
  }
  function closeMenu(returnFocus) {
    if (drawer.hidden) return;
    drawer.classList.remove('is-open');
    burger.setAttribute('aria-expanded', 'false');
    burger.setAttribute('aria-label', 'Открыть меню');
    unlockScroll();
    if (returnFocus) burger.focus({ preventScroll: true });
    drawerTimer = setTimeout(function () { drawer.hidden = true; }, reduce ? 0 : 380);
  }
  burger.addEventListener('click', function () { if (drawer.hidden || !drawer.classList.contains('is-open')) openMenu(); else closeMenu(true); });
  drawer.addEventListener('click', function (e) {
    if (e.target.closest('[data-drawer-close]')) closeMenu(true);
    else if (e.target.closest('.drawer__nav a')) closeMenu(false); // page scroll is restored first, then the anchor jump runs
  });
  drawer.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { e.preventDefault(); closeMenu(true); return; }
    if (e.key !== 'Tab') return;
    var f = focusables(), first = f[0], lastF = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); lastF.focus(); }
    else if (!e.shiftKey && document.activeElement === lastF) { e.preventDefault(); first.focus(); }
  });
  function onMq() { if (!mobile.matches) closeMenu(false); }
  if (mobile.addEventListener) mobile.addEventListener('change', onMq); else mobile.addListener(onMq);

  /* ---- Active nav item ---- */
  var links = $$('.nav a, .drawer__nav a');
  if ('IntersectionObserver' in window) {
    var navIO = new IntersectionObserver(function (es) {
      es.forEach(function (en) {
        if (!en.isIntersecting) return;
        links.forEach(function (a) { a.classList.toggle('is-active', a.getAttribute('href') === '#' + en.target.id); });
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    $$('main section[id]').forEach(function (s) { navIO.observe(s); });
  }

  /* ---- Image reveal (only for images that start below the fold) ---- */
  var reveals = $$('.reveal');
  if (!reduce && 'IntersectionObserver' in window) {
    var revIO = new IntersectionObserver(function (es) {
      es.forEach(function (en) { if (en.isIntersecting) { en.target.classList.remove('is-pending'); revIO.unobserve(en.target); } });
    }, { rootMargin: '0px 0px 0px 0px' });
    reveals.forEach(function (el) {
      if (el.getBoundingClientRect().top > window.innerHeight) { el.classList.add('is-pending'); revIO.observe(el); }
    });
  }

  /* ---- Statement lines in the photo band ---- */
  $$('[data-lines]').forEach(function (el) {
    if (reduce || !('IntersectionObserver' in window) || el.getBoundingClientRect().top < window.innerHeight) return;
    el.classList.add('is-pending');
    var io = new IntersectionObserver(function (es) {
      if (es[0].isIntersecting) { el.classList.remove('is-pending'); io.disconnect(); }
    }, { rootMargin: '0px 0px -20% 0px' });
    io.observe(el);
  });

  /* ---- Fast images: once the first screen is in, fetch every other picture in the background,
     a few at a time, at the size this screen needs. Scrolling then never waits for the network.
     The variant that is hidden at this width (service photos differ on desktop and mobile) is skipped. */
  function loadAllImages() {
    var queue = $$('img[loading="lazy"]').filter(function (im) {
      var box = im.closest('.svc__media, .svc__pic');
      return !(box && getComputedStyle(box).display === 'none');
    });
    var active = 0;
    function next() {
      while (active < 4 && queue.length) {
        var im = queue.shift();
        if (im.complete && im.naturalWidth) continue;
        active++;
        var done = function () { active--; next(); };
        im.addEventListener('load', done, { once: true });
        im.addEventListener('error', done, { once: true });
        im.loading = 'eager';
      }
    }
    next();
  }
  if (document.readyState === 'complete') setTimeout(loadAllImages, 0);
  else window.addEventListener('load', function () { setTimeout(loadAllImages, 0); });

  /* ---- Warm up images inside tabs before the visitor reaches them ---- */
  if ('IntersectionObserver' in window) {
    var warm = new IntersectionObserver(function (es) {
      es.forEach(function (en) {
        if (!en.isIntersecting) return;
        $$('img[loading="lazy"]', en.target).forEach(function (im) {
          var box = im.closest('.svc__media, .svc__pic'); // only the variant shown at this width
          if (box && getComputedStyle(box).display === 'none') return;
          var pre = new Image();
          if (im.srcset) { pre.sizes = im.sizes; pre.srcset = im.srcset; }
          pre.src = im.currentSrc || im.src;
        });
        warm.unobserve(en.target);
      });
    }, { rootMargin: '800px 0px' });
    $$('[data-tabs], [data-svc]').forEach(function (el) { warm.observe(el); });
  }

  /* ---- Hero parallax + process steps lit by reading position ---- */
  var scene = $('[data-parallax]'), stepsEl = $('[data-steps]');
  var steps = stepsEl ? $$('.step', stepsEl) : [];
  var ticking = false;
  function frame() {
    ticking = false;
    var vh = window.innerHeight;
    if (scene && !reduce && !mobile.matches) {
      var y = Math.min(window.scrollY, vh);
      scene.style.transform = 'translate3d(0,' + (y * 0.12).toFixed(1) + 'px,0)';
    }
    if (stepsEl) {
      var line = vh * 0.62, last = -1;
      steps.forEach(function (li, i) {
        var on = reduce || li.getBoundingClientRect().top + 22 < line;
        li.classList.toggle('is-on', on);
        if (on) last = i;
      });
      var r = stepsEl.getBoundingClientRect();
      var p = reduce ? 1 : Math.max(0, Math.min(1, (line - r.top - 28) / Math.max(1, r.height - 56)));
      if (last === steps.length - 1 && !reduce) p = Math.max(p, 1);
      stepsEl.style.setProperty('--p', p.toFixed(3));
    }
  }
  window.addEventListener('scroll', function () {
    onScroll();
    if (!ticking) { ticking = true; requestAnimationFrame(frame); }
  }, { passive: true });
  window.addEventListener('resize', frame);
  onScroll(); frame();

  /* ---- Switch only when the picture is ready: load + decode first, keep the old one meanwhile ---- */
  function shownImgs(scope) {
    return $$('img', scope).filter(function (im) {
      var box = im.closest('.svc__media, .svc__pic');
      return !(box && getComputedStyle(box).display === 'none');
    });
  }
  function whenReady(imgs, ms) {
    return new Promise(function (res) {
      var left = imgs.length, t;
      if (!left) return res();
      t = setTimeout(res, ms);
      imgs.forEach(function (im) {
        var fin = function () { if (--left <= 0) { clearTimeout(t); res(); } };
        var dec = function () { if (im.decode) im.decode().then(fin, fin); else fin(); };
        im.loading = 'eager';
        if (im.complete && im.naturalWidth) dec();
        else { im.addEventListener('load', dec, { once: true }); im.addEventListener('error', fin, { once: true }); }
      });
    });
  }
  function prefetch(imgs) { imgs.forEach(function (im) { if (!(im.complete && im.naturalWidth)) im.loading = 'eager'; }); }

  /* ---- Tabs (scale switcher, engineering) ---- */
  $$('[data-tabs]').forEach(function (root) {
    var tabs = $$('[role="tab"]', root);
    var token = 0;
    function select(tab, focus) {
      tabs.forEach(function (t) {
        var on = t === tab;
        t.setAttribute('aria-selected', String(on));
        t.tabIndex = on ? 0 : -1;
      });
      if (focus) tab.focus({ preventScroll: true });
      var my = ++token, panel = document.getElementById(tab.getAttribute('aria-controls'));
      whenReady(shownImgs(panel), 1500).then(function () {
        if (my !== token) return;
        tabs.forEach(function (t) { document.getElementById(t.getAttribute('aria-controls')).hidden = t !== tab; });
      });
      // On phones the picker is a swipe strip: bring the chosen card into view inside it, never scroll the page
      var strip = tab.parentNode;
      if (strip.scrollWidth > strip.clientWidth + 2) {
        var pad = parseFloat(getComputedStyle(strip).paddingLeft) || 0;
        var to = tab.offsetLeft - strip.offsetLeft - pad;
        if (strip.scrollTo) strip.scrollTo({ left: to, behavior: reduce ? 'auto' : 'smooth' }); else strip.scrollLeft = to;
      }
    }
    // Phones: one card at a time with arrows (the strip used to hide the rest behind the edge)
    var strip0 = tabs.length && tabs[0].parentNode;
    if (strip0 && strip0.classList.contains('picker')) {
      var bar = document.createElement('div');
      bar.className = 'pickbar';
      var chev = function (d) { return '<svg viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="' + d + '"/></svg>'; };
      var prev = document.createElement('button'), next = document.createElement('button'), count = document.createElement('p');
      prev.type = next.type = 'button';
      prev.className = 'pickbar__btn'; next.className = 'pickbar__btn';
      prev.setAttribute('aria-label', 'Предыдущий вариант'); next.setAttribute('aria-label', 'Следующий вариант');
      prev.innerHTML = chev('M11 4 6 9l5 5'); next.innerHTML = chev('M7 4l5 5-5 5');
      count.className = 'pickbar__count'; count.setAttribute('aria-hidden', 'true');
      strip0.parentNode.insertBefore(bar, strip0);
      bar.appendChild(prev); bar.appendChild(strip0); bar.appendChild(next); bar.appendChild(count);
      var cur = function () { for (var k = 0; k < tabs.length; k++) if (tabs[k].getAttribute('aria-selected') === 'true') return k; return 0; };
      var upd = function () { count.textContent = (cur() + 1) + ' из ' + tabs.length; };
      prev.addEventListener('click', function () { select(tabs[(cur() - 1 + tabs.length) % tabs.length]); upd(); });
      next.addEventListener('click', function () { select(tabs[(cur() + 1) % tabs.length]); upd(); });
      tabs.forEach(function (t) { t.addEventListener('click', upd); t.addEventListener('keydown', function () { setTimeout(upd, 0); }); });
      var warmAll = function () { tabs.forEach(function (t) { prefetch(shownImgs(document.getElementById(t.getAttribute('aria-controls')))); }); };
      prev.addEventListener('touchstart', warmAll, { passive: true }); next.addEventListener('touchstart', warmAll, { passive: true });
      prev.addEventListener('pointerenter', warmAll); next.addEventListener('pointerenter', warmAll);
      upd();
    }
    tabs.forEach(function (tab, i) {
      var warmTab = function () { prefetch(shownImgs(document.getElementById(tab.getAttribute('aria-controls')))); };
      tab.addEventListener('pointerenter', warmTab); tab.addEventListener('touchstart', warmTab, { passive: true }); tab.addEventListener('focus', warmTab);
      tab.addEventListener('click', function () { select(tab); });
      tab.addEventListener('keydown', function (e) {
        var j = null;
        if (e.key === 'ArrowRight') j = (i + 1) % tabs.length;
        else if (e.key === 'ArrowLeft') j = (i - 1 + tabs.length) % tabs.length;
        else if (e.key === 'Home') j = 0;
        else if (e.key === 'End') j = tabs.length - 1;
        if (j !== null) { e.preventDefault(); select(tabs[j], true); }
      });
    });
  });

  /* ---- Services: click opens one service, image follows ---- */
  $$('[data-svc]').forEach(function (root) {
    var btns = $$('.svc__btn', root), imgs = $$('.svc__media img', root);
    var token = 0;
    function forBtn(btn) {
      var id = btn.getAttribute('aria-controls');
      return shownImgs(root).filter(function (im) { return im.getAttribute('data-for') === id || im.closest('#' + id); });
    }
    function open(btn) {
      var closing = btn.getAttribute('aria-expanded') === 'true';
      var my = ++token;
      btns.forEach(function (b) { b.setAttribute('aria-expanded', String(b === btn && !closing)); });
      if (closing) { document.getElementById(btn.getAttribute('aria-controls')).hidden = true; return; }
      var id = btn.getAttribute('aria-controls');
      whenReady(forBtn(btn), 1200).then(function () {
        if (my !== token) return;
        btns.forEach(function (b) { document.getElementById(b.getAttribute('aria-controls')).hidden = b !== btn; });
        // Cross-fade: the new picture fades in over the old one, the old one stays until it is covered
        imgs.forEach(function (im) {
          var on = im.getAttribute('data-for') === id;
          if (im.classList.contains('is-on') && !on) { im.classList.add('was-on'); setTimeout(function () { im.classList.remove('was-on'); }, 800); }
          im.classList.toggle('is-on', on);
        });
      });
    }
    btns.forEach(function (b) {
      var w = function () { prefetch(forBtn(b)); };
      b.addEventListener('pointerenter', w); b.addEventListener('touchstart', w, { passive: true }); b.addEventListener('focus', w);
      b.addEventListener('click', function () { open(b); });
    });
  });

  /* ---- Security atlas: pins and legend share one state; a second click closes ---- */
  $$('[data-atlas]').forEach(function (root) {
    var pins = $$('.pin', root), btns = $$('.legend__btn', root), cur = null;
    function set(i) {
      cur = (i === cur) ? null : i;
      pins.forEach(function (p) { var on = p.getAttribute('data-risk') === cur; p.classList.toggle('is-on', on); p.setAttribute('aria-pressed', String(on)); });
      btns.forEach(function (b) {
        var on = b.getAttribute('data-risk') === cur;
        b.setAttribute('aria-expanded', String(on));
        document.getElementById(b.getAttribute('aria-controls')).hidden = !on;
      });
    }
    pins.forEach(function (p) { p.addEventListener('click', function () { set(p.getAttribute('data-risk')); }); });
    btns.forEach(function (b) { b.addEventListener('click', function () { set(b.getAttribute('data-risk')); }); });
    set('0');
  });

  /* ---- Forms: one template, inline (#contact) and modal ---- */
  var tpl = $('#form-tpl');
  function mount(host, suffix) {
    var frag = tpl.content.cloneNode(true);
    $$('[id]', frag).forEach(function (el) { el.id += suffix; });
    $$('label[for]', frag).forEach(function (el) { el.htmlFor += suffix; });
    $$('[aria-labelledby]', frag).forEach(function (el) { el.setAttribute('aria-labelledby', el.getAttribute('aria-labelledby') + suffix); });
    host.appendChild(frag);
    var form = $('form', host);
    wire(form);
    return form;
  }
  function wire(form) {
    var name = form.elements.name, phone = form.elements.phone, files = form.elements.files || form.elements['files[]'];
    var status = $('.form__status', form), list = $('.file__list', form), hint = list.textContent;
    function err(input, show) {
      var e = $('.field__err', input.parentNode);
      e.id = input.id + '-err';
      input.setAttribute('aria-invalid', show ? 'true' : 'false');
      if (show) input.setAttribute('aria-describedby', e.id); else input.removeAttribute('aria-describedby');
      e.hidden = !show;
    }
    var consent = form.elements.consent, born = Date.now(); // consent exists only when WordPress has a privacy policy page
    function check() {
      var okN = name.value.trim().length > 0, okP = phone.value.replace(/\D/g, '').length >= 10;
      var okC = !consent || consent.checked;
      err(name, !okN); err(phone, !okP);
      if (consent) err(consent, !okC);
      return !okN ? name : (!okP ? phone : (!okC ? consent : null));
    }
    if (consent) consent.addEventListener('change', function () { if (consent.getAttribute('aria-invalid') === 'true') check(); });
    [name, phone].forEach(function (el) { el.addEventListener('input', function () { if (el.getAttribute('aria-invalid') === 'true') check(); status.hidden = true; }); });
    var comment = form.elements.comment;
    $$('.chip', form).forEach(function (chip) {
      chip.setAttribute('aria-pressed', 'false');
      chip.addEventListener('click', function () {
        var line = chip.getAttribute('data-chip') + ': ';
        var v = comment.value;
        if (v.indexOf(line) === -1) comment.value = (v && !/\n$/.test(v) ? v + '\n' : v) + line;
        chip.setAttribute('aria-pressed', 'true');
        comment.focus();
        comment.setSelectionRange(comment.value.length, comment.value.length);
      });
    });
    comment.addEventListener('input', function () {
      $$('.chip', form).forEach(function (chip) {
        chip.setAttribute('aria-pressed', String(comment.value.indexOf(chip.getAttribute('data-chip') + ':') !== -1));
      });
    });
    files.addEventListener('change', function () {
      list.textContent = files.files.length ? Array.prototype.map.call(files.files, function (f) { return f.name; }).join(', ') : hint;
    });
    var btn = $('[type="submit"]', form), btnText = btn.textContent;
    function say(html, ok) {
      status.innerHTML = html;
      status.classList.toggle('is-ok', !!ok);
      status.hidden = false;
    }
    function callUs() { return 'Позвоните, чтобы обсудить проект: <a href="' + PHONE_HREF + '">' + PHONE + '</a>.'; }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var bad = check();
      if (bad) { bad.focus(); status.hidden = true; return; }
      /* Static demo (no WordPress): be honest, nothing is sent. */
      if (!CFG || !CFG.ajaxUrl) {
        say('Демо-режим: заявка <b>не отправлена</b>, форма ещё не подключена. ' + callUs());
        return;
      }
      /* WordPress: check files before upload, then post to admin-ajax. */
      var fl = files.files, maxN = CFG.maxFiles || 5, maxB = (CFG.maxFileMb || 10) * 1048576, total = 0;
      if (fl.length > maxN) { say('Можно прикрепить не больше ' + maxN + ' файлов.'); return; }
      for (var i = 0; i < fl.length; i++) {
        total += fl[i].size;
        if (fl[i].size > maxB) { say('Файл «' + fl[i].name + '» больше ' + (CFG.maxFileMb || 10) + ' МБ.'); return; }
      }
      if (form.getAttribute('data-busy')) return;
      form.setAttribute('data-busy', '1');
      btn.disabled = true; btn.textContent = 'Отправляем…';
      status.hidden = true;
      var fd = new FormData(form);
      fd.append('action', 'ironcore_lead');
      fd.append('nonce', CFG.nonce);
      fd.append('page_url', location.href);
      fd.append('elapsed', String(Date.now() - born));
      function done() { form.removeAttribute('data-busy'); btn.disabled = false; btn.textContent = btnText; }
      fetch(CFG.ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(function (r) { return r.json().catch(function () { return null; }); })
        .then(function (res) {
          done();
          if (res && res.success) {
            form.reset();
            born = Date.now();
            list.textContent = hint;
            $$('.chip', form).forEach(function (c) { c.setAttribute('aria-pressed', 'false'); });
            say((res.data && res.data.message) || 'Заявка отправлена. Мы свяжемся с вами.', true);
          } else {
            say(((res && res.data && res.data.message) || 'Не удалось отправить заявку.') + ' ' + callUs());
          }
        }, function () {
          done();
          say('Нет связи с сервером, заявка не отправлена. ' + callUs());
        });
    });
  }
  $$('[data-form-host="inline"]').forEach(function (h) { mount(h, '-c').elements.source.value = 'Форма в разделе «Контакты»'; });

  /* ---- Modal ---- */
  var modal = $('#modal'), mForm = mount($('[data-form-host="modal"]', modal), '-m'), mTitle = $('#modal-title'), last = null;
  function openModal(label, trigger) {
    last = trigger && trigger.closest('#drawer') ? burger : trigger;
    mTitle.textContent = label === 'Связаться' ? 'Обсудить проект' : label;
    mForm.elements.source.value = label;
    $('.form__status', mForm).hidden = true;
    if (modal.showModal) modal.showModal(); else modal.setAttribute('open', '');
    document.body.classList.add('no-scroll');
    closeMenu(false);
    setTimeout(function () { mForm.elements.name.focus(); }, 40);
  }
  function onClose() { document.body.classList.remove('no-scroll'); if (last) last.focus(); }
  modal.addEventListener('close', onClose);
  modal.addEventListener('click', function (e) {
    if (e.target === modal || e.target.closest('[data-close]')) { if (modal.close) modal.close(); else { modal.removeAttribute('open'); onClose(); } }
  });
  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-modal]');
    if (t) { e.preventDefault(); openModal(t.getAttribute('data-modal'), t); }
  });
})();
